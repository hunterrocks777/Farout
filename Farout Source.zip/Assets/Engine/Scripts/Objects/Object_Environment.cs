﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "Env_New"), System.Serializable]
public class Object_Environment : ScriptableObject
{
    public string Name = "New Environment";
    [Range(2f, 30f)] public float HeightMultiplier = 5f;
    [Range(1f, 10f)] public float Scale = 5f;
    [Range(0.01f, 1.00f)] public float ObjectSpawnChance = 0.9f;
    public Material Skybox;
    public Color Light_Color = Color.white;
    [Range(0.05f, 0.25f)] public float Fog_Density = 0.05f;
    public Color Fog_Color = Color.blue;
    public Texture Ground;
    public int GlobalTemprature = 60; //In Farenheit
    public GameObject[] PassiveMobs;
    public GameObject[] HostileMobs;
    public Object_Environment_SpawnableObjects[] SpawnableObjects;
}
[System.Serializable]
public class Object_Environment_SpawnableObjects 
{
    public GameObject Object;
    [Range(1, 100)] public int Probability;
}