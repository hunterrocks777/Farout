﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[CreateAssetMenu(fileName = "Buildable_New"), System.Serializable]
public class Object_Buildable : ScriptableObject
{
    public string Name;
    public Mesh Mesh;
    public Texture Texture;
    public Sprite UI_Sprite;

    public string Object_Effect = "";
    public int HP;
    public Color LightEmmitance;
    public int Temperature;
}
