﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Random = System.Random;

public static class Extension_RandomExtensions
{
    public static float Range(this Random random, float min = 0f, float max = 1f)
    {
        // thank you to Zenvin for this genius solution
        return Mathf.Lerp(min, max, (float)random.NextDouble());
    }
}
