﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[CreateAssetMenu(fileName = "Item_New"), System.Serializable]
public class Object_Item : ScriptableObject
{
    public string Name = "Item";
    public Sprite UI_Sprite;
    public Mesh Mesh;
    public Texture Texture;
}
