﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[CreateAssetMenu(fileName = "Consumable_New"), System.Serializable]
public class Object_Consumable : ScriptableObject
{
    public string Name;
    public Mesh Mesh;
    public Texture Texture;
    public Sprite UI_Sprite;

    public string Consumable_Effect;
    public int Consumable_EffectAddition;
}
