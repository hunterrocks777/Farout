﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[CreateAssetMenu(fileName = "Weapon_New"), System.Serializable]
public class Object_Weapon : ScriptableObject
{
    public string Name = "Weapon";
    public Sprite UI_Sprite;
    public int AttackDamage = 15;
    public float AttackInterval = 0.25f;
    public int AttackRange = 25;

    public string Weapon_Type = "";

    public string Animation_Idle = "melee_idle";
    public string Animation_Attack = "melee_attack";
    public AudioClip Audio_Attack;
    public Mesh Mesh;
    public Texture Texture;
    public Color WeaponEmitance = Color.black;
    public int WeaponHeat = 0;
}
