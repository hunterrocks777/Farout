﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[CreateAssetMenu(fileName = "Blueprint_New"), System.Serializable]
public class Object_Blueprint : ScriptableObject
{
    public string Name = "Blueprint";
    public Sprite UI_Sprite;
    public ScriptableObject ToCraft;
    public ScriptableObject[] Materials = new ScriptableObject[1];
    public string[] Material_Names = new string[1];
}
