﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity_Bed : MonoBehaviour
{
    public void Bed_Sleep() 
    {
        FindObjectOfType<Handler_Gamehandler>().world.Sun.Time_Time = 6;
        FindObjectOfType<Handler_Gamehandler>().world.Sun.Time_Day += 1;
    }
}
