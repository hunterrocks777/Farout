﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity_Pickup : MonoBehaviour
{
    public ScriptableObject[] Spawning;
    [HideInInspector] public int ID;
    public bool Randomize;

    MeshFilter filter;
    MeshRenderer render;
    Handler_Gamehandler handler;
    // Start is called before the first frame update
    void Start()
    {
        handler = FindObjectOfType<Handler_Gamehandler>();
        Handler_ObjectHandler objects = FindObjectOfType<Handler_ObjectHandler>();
        filter = GetComponent<MeshFilter>();
        render = GetComponent<MeshRenderer>();
        if (Randomize)
        {
            if (Spawning.Length == 0)
            {
                ID = Random.Range(0, objects.Items.Length);
            }
            else
            {
                int i = Random.Range(0, Spawning.Length);
                ID = objects.getItemID(Spawning[i]);
            }
        }
    }

    private void Update()
    {
        ScriptableObject item = handler.objects.Items[ID];
        if (item is Object_Weapon)
        {
            filter.mesh = ((Object_Weapon)item).Mesh;
            render.material.mainTexture = ((Object_Weapon)item).Texture;
        }
        if (item is Object_Item)
        {
            filter.mesh = ((Object_Item)item).Mesh;
            render.material.mainTexture = ((Object_Item)item).Texture;
        }
        if (item is Object_Consumable)
        {
            filter.mesh = ((Object_Consumable)item).Mesh;
            render.material.mainTexture = ((Object_Consumable)item).Texture;
        }
    }
    public void Item_Pickup(Entity_Player player) 
    {
        bool doDestroy = player.MyInventory.Inventory_NewItem(ID);
        if (doDestroy)
        {
            Destroy(gameObject);
        }
    }
    private void OnTriggerEnter(Collider other)
    {
        Entity_Player player = other.GetComponent<Entity_Player>();
        if (player) 
        {
            bool doDestroy = player.MyInventory.Inventory_NewItem(ID);
            if (doDestroy) 
            {
                Destroy(gameObject);
            }
        }
    }
}
