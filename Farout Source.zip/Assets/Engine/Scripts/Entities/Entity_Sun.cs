﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity_Sun : MonoBehaviour
{
    public float Time_Day;
    public float Time_Time = 6; //6 AM
    public float Time_Multiplier = 1;
    public bool Time_Change = true;
    float multiplier;
    float multiplierAmount;
    Handler_Gamehandler handler;
    private void Start()
    {
        Time_Time = 6; //6 AM
        handler = FindObjectOfType<Handler_Gamehandler>();
    }
    void Update()
    {
        if (Time_Change && !handler.World_Paused)
        {
            Time_Time += Time.deltaTime * 0.1f * Time_Multiplier;
        }
        transform.rotation = Quaternion.Euler(Time_Time * 15 - 90, 45 * (Time_Time / 360), Time_Time * -7.5f);
        if (Time_Time >= 24)
        {
            Time_Time = 0;
            Time_Day++;
        }
        //Multiplier  || Time_Time <= 24 && Time_Time >= 6f
        if (Time_Time <= 18 && Time_Time >= 6) 
        {
            multiplier = 1;
        }
        else 
        {
            multiplier = 0;
        }
        LightingMultiplier();
    }
    public void LightingMultiplier() 
    {
        multiplierAmount = Mathf.Lerp(multiplierAmount, multiplier, 0.01f);
        Mathf.Clamp(multiplierAmount, 0, 1);
        GetComponent<Light>().intensity = multiplierAmount;
        RenderSettings.fogDensity = handler.objects.Environments[handler.world.World_CurrentEnvironment].Fog_Density * multiplierAmount;
        RenderSettings.ambientIntensity = multiplierAmount;
    }
}
