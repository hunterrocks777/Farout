﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity_Buildable : MonoBehaviour
{
    GameObject camera;
    bool isPlaced;

    // Start is called before the first frame update
    void Start()
    {
        camera = FindObjectOfType<Camera>().gameObject;
    }
    void Update()
    {
        if (isPlaced)
        {
            GetComponent<MeshRenderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On;
            GetComponent<MeshCollider>().enabled = true;
        }
        else 
        {
            GetComponent<MeshCollider>().enabled = false;
            GetComponent<MeshRenderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            RaycastHit hit = new RaycastHit();
            Ray ray = new Ray(camera.transform.position, camera.transform.forward);
            FindObjectOfType<Entity_Player>().LookAt_Name = "Press RMB to place building/ Q/E to rotate";
            if (Physics.Raycast(ray, out hit, 10))
            {
                if (!hit.transform.GetComponent<Entity_NPC>())
                {
                    transform.position = hit.point;
                    if (Input.GetKey(KeyCode.Mouse1)) 
                    {
                        isPlaced = true;
                        transform.SetParent(hit.transform);
                        FindObjectOfType<Entity_Player>().canAttack = true;
                    }
                    if (Input.GetKey(KeyCode.Q)) 
                    {
                        transform.Rotate(0, -15, 0);
                    }
                    if (Input.GetKey(KeyCode.E))
                    {
                        transform.Rotate(0, 15, 0);
                    }
                }
            }
        }
    }
}
