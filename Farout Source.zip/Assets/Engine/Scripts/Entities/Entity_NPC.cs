﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity_NPC : MonoBehaviour
{
    public int NPC_Health_Max = 100;
    [HideInInspector] public int NPC_Health_Current = 100;
    public float NPC_Speed_Default = 5;
    public int NPC_Weapon_BaseDamage = 10;
    public GameObject NPC_Weapon_Gameobject;
    public Object_Weapon NPC_Weapon_SO;
    public ScriptableObject NPC_ItemDropped;

    [Range(0, 2)] public int NPC_AI_Behavior = 1;

    [HideInInspector] public Entity_NPC_Team npc_team;
    [HideInInspector] public Vector3 npc_target_pos;
    [HideInInspector] public string npc_animation_current;
    [HideInInspector] public bool npc_ai_angered;
    [HideInInspector] public float npc_ai_timer;
    [HideInInspector] public GameObject npc_target_gameobject;
    [HideInInspector] public GameObject npc_target_searchgameobject;
    [HideInInspector] public bool npc_canmove;
    [HideInInspector] public bool npc_canfire;
    [HideInInspector] public Vector3 npc_velocity;
    [HideInInspector] public Vector3 npc_oldpos;
    [HideInInspector] public float npc_direction;

    Handler_Gamehandler handler;
    CharacterController charcontroller;
    // Start is called before the first frame update
    void Start()
    {
        npc_canfire = true;
        NPC_Health_Current = NPC_Health_Max;
        handler = FindObjectOfType<Handler_Gamehandler>();
        charcontroller = GetComponent<CharacterController>();
        npc_team = GetComponent<Entity_NPC_Team>();
        AI_RandomPosition();
    }

    // Update is called once per frame
    void Update()
    {
        if (handler.World_UIScreen != "mainmenu" && handler.World_UIScreen != "loading" && !handler.World_Paused)
        {
            NPC_AI();
            NPC_Movement();
            NPC_Combat();
        }
        if (distance(transform.position, handler.world.Player.transform.position) >= (16 * 2) + (16 * handler.world.World_ChunkDist))
        {
            Destroy(gameObject);
        }
    }
    void NPC_Movement()
    {
        float velocity_oldy = npc_velocity.y;
        if (npc_canmove)
        {
            npc_velocity = transform.forward * NPC_Speed_Default;
        }
        else
        {
            npc_velocity = transform.forward * 0;
        }
        npc_velocity.y = velocity_oldy;
        if (charcontroller.isGrounded)
        {
            npc_velocity.y = 0;
        }
        npc_velocity += Physics.gravity * Time.deltaTime;

        charcontroller.Move(npc_velocity * Time.deltaTime);
        if (npc_oldpos == transform.position) 
        {
            npc_ai_timer = 0;
        }
        npc_oldpos = transform.position;
    }
    void NPC_AI()
    {
        if (npc_target_gameobject)
        {
            npc_target_pos = npc_target_gameobject.transform.position;
        }
        npc_canmove = distance(transform.position, npc_target_pos) > 1;
        npc_ai_timer -= Time.deltaTime;
        //Passive
        if (NPC_AI_Behavior == 0)
        {
            if (npc_ai_angered || npc_target_gameobject)
            {
                AI_Behavior_KeepTarget();
                AI_LookTowards(true);
            }
            else 
            {
                AI_LookTowards(false);
                if (npc_ai_timer <= 0)
                {
                    AI_RandomPosition();
                }
            }
        }
        //Neutral
        if (NPC_AI_Behavior == 1)
        {
            if (npc_ai_angered || npc_target_gameobject)
            {
                AI_Behavior_KeepTarget();
                AI_LookTowards(false);
            }
            else
            {
                AI_LookTowards(false);
                if(npc_ai_timer <= 0) 
                {
                    AI_RandomPosition();
                }
            }
        }
        //Hostile
        if (NPC_AI_Behavior == 2)
        {
            if (npc_ai_angered || npc_target_gameobject)
            {
                AI_Behavior_KeepTarget();
                AI_LookTowards(false);
            }
            else
            {
                AI_Behavior_FindTargets();
                AI_LookTowards(false);
                if (npc_ai_timer <= 0)
                {
                    AI_RandomPosition();
                }
            }
        }
    }
    void AI_RandomPosition() 
    {
        npc_ai_timer = Random.Range(5, 30);
        npc_target_pos = transform.position + new Vector3(Random.Range(-20, 20), 0, Random.Range(-20, 20));
    }
    void AI_LookTowards(bool reverse) 
    {
        if (npc_canmove)
        {
            transform.LookAt(npc_target_pos);
            if (!reverse)
            {
                transform.localEulerAngles = new Vector3(0, transform.localEulerAngles.y, 0);
            }
            else
            {
                transform.localEulerAngles = new Vector3(0, transform.localEulerAngles.y + 180, 0);
            }
        }
    }
    void AI_Behavior_FindTargets()
    {
        Collider[] mobs = Physics.OverlapSphere(transform.position, 10, 1 << 8);
        if (mobs.Length != 0)
        {
            foreach (Collider coll in mobs)
            {
                Entity_NPC_Team mob = coll.GetComponent<Entity_NPC_Team>();
                if (mob)
                {
                    if (mob.Faction != npc_team.Faction)
                    {
                        Vector3 heading = mob.transform.position - transform.position;
                        float dot = Vector3.Dot(heading, transform.forward);
                        if (heading.magnitude <= 10)
                        {
                            //Distance Check
                            if (dot > 0.9f && Physics.Linecast(transform.position, mob.transform.position))
                            {
                                //In FOV check
                                npc_target_gameobject = mob.gameObject;
                                //npc_target_gameobject_Distance = Random.Range(3, 15);
                            }
                        }
                    }
                }
            }

        }
    }
    void AI_Behavior_KeepTarget()
    {
        if (npc_target_gameobject != null)
        {
            Vector3 heading =npc_target_gameobject.transform.position - transform.position;
            if (Physics.Raycast(transform.position, heading, out RaycastHit hit))
            {
                Entity_Player player =npc_target_gameobject.GetComponent<Entity_Player>();
                Entity_NPC mob =npc_target_gameobject.GetComponent<Entity_NPC>();
                if (hit.transform.gameObject !=npc_target_gameobject)
                {
                    //Mob_AI_Timer = 0;
                    npc_target_searchgameobject = npc_target_gameobject;
                    npc_target_pos = npc_target_gameobject.transform.position;
                    npc_target_gameobject = null;
                }
                else
                {
                    if (mob)
                    {
                        if (mob.NPC_Health_Current <= 0)
                        {
                            //Mob_AI_Timer = 0;
                            npc_target_gameobject = null;
                            //Mob_AI_Provoked = false;
                        }
                    }
                    if (player)
                    {
                        if (player.Player_Health <= 0)
                        {
                            //Mob_AI_Timer = 0;
                            npc_target_gameobject = null; ;
                            //Mob_AI_Provoked = false;
                        }
                    }
                }
            }
            else
            {
                //Mob_AI_Timer = 0;
                npc_target_searchgameobject = npc_target_gameobject;
                npc_target_pos = npc_target_gameobject.transform.position;
                npc_target_gameobject = null;
            }
        }
        else
        {
            if (npc_target_searchgameobject != null)
            {
                Vector3 heading = npc_target_searchgameobject.transform.position - transform.position;
                if (Physics.Raycast(transform.position, heading, out RaycastHit hit))
                {
                    if (hit.transform.gameObject ==npc_target_searchgameobject)
                    {
                       npc_target_gameobject =npc_target_searchgameobject;
                       npc_target_searchgameobject = null;
                    }
                }
                /*
                if (Mob_AI_Timer <= 0.25f)
                {
                   npc_target_gameobject_LookingFor = null;
                    Mob_AI_Provoked = false;
                }
                */
            }
        }
    }
    public void NPC_Hurt(int dmg, GameObject origin) 
    {
        NPC_Health_Current -= dmg;
        if (NPC_Health_Current <= 0)
        {
            NPC_Death();
        }
        else if (origin)
        {
            npc_target_gameobject = origin;
            npc_ai_angered = true;
        }
    }
    void NPC_Death() 
    {
        handler.Game_CreateEffect("effect_death", transform.position);
        handler.Game_CreateItem(handler.objects.getItemID(NPC_ItemDropped), transform.position);
        Destroy(gameObject);
    }
    void NPC_Combat()
    {
        if (NPC_Weapon_Gameobject) 
        {
            NPC_Weapon_Gameobject.GetComponent<MeshFilter>().mesh = NPC_Weapon_SO.Mesh;
            NPC_Weapon_Gameobject.GetComponent<MeshRenderer>().material.mainTexture = NPC_Weapon_SO.Texture;
        }
        if (npc_target_gameobject)
        {
            if (distance(transform.position, npc_target_pos) >= NPC_Weapon_SO.AttackRange && npc_canfire)
            {
                NPC_Combat_Attack();
            }
        }
    }
    void NPC_Combat_Attack() 
    {
        npc_canfire = false;
        RaycastHit hit = new RaycastHit();
        Ray ray = new Ray(transform.position, transform.forward);
        if (Physics.Raycast(ray, out hit, NPC_Weapon_SO.AttackRange))
        {
            Debug.DrawRay(transform.position, transform.forward);
            if (hit.transform.GetComponent<MeshRenderer>())
            {
                handler.Game_CreateEffect_BreakParticle(hit.point, (Texture2D)hit.transform.GetComponent<MeshRenderer>().material.mainTexture);
            }
            handler.sound.createAudioClipLibrary("hit", hit.point);
            Entity_Destructable destruc = hit.transform.GetComponent<Entity_Destructable>();
            Entity_Player player = hit.transform.GetComponent<Entity_Player>();
            if (destruc)
            {
                destruc.Entity_HP -= NPC_Weapon_SO.AttackDamage;
            }
            if (player) 
            {
                player.Player_Hurt(Mathf.FloorToInt(NPC_Weapon_SO.AttackDamage * handler.prefs.Prefs.Gameplay_Difficulty));
            }
        }
        //Invoke a function to allow the player to fire again
        Invoke("NPC_Combat_AttackEnd", NPC_Weapon_SO.AttackInterval);
    }
    void NPC_Combat_AttackEnd() 
    {
        npc_canfire = true;
    }

    float distance(Vector3 a, Vector3 b) 
    {
        return Vector3.Distance(new Vector3(a.x, 0, a.z), new Vector3(b.x, 0, b.z));
    }
}
