﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity_NPC_Team : MonoBehaviour
{
    public string Faction = "faction";
}
