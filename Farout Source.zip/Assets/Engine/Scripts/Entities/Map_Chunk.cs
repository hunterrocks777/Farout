﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using Random = System.Random;

public class Map_Chunk : MonoBehaviour
{
    Random rand;
    public int ChunkSizeX = 16;
    public int ChunkSizeY = 16;

    FastNoiseLite noise = new FastNoiseLite();

    Vector3[] vertices;
    int[] triangles;
    Mesh chunkmesh;
    bool spawnedHostile;
    Handler_MapHandler world;
    // Start is called before the first frame update
    void Start()
    {
        world = FindObjectOfType<Handler_MapHandler>();
        chunkmesh = new Mesh();
        GetComponent<MeshFilter>().mesh = chunkmesh;
        GenerateChunk();
        DrawChunk();
        GenerateObjects();

        SpawnPassiveMobs();
    }
    private void Update()
    {
        if (world.Sun.Time_Time >= 19 || world.Sun.Time_Time <= 5)
        {
            if (!spawnedHostile && world.handler.prefs.Prefs.Gameplay_Difficulty != 0.25f)
            {
                SpawnHostileMobs();
            }
        }
        if (world.Sun.Time_Time >= 8 && world.Sun.Time_Time <= 16)
        {
            if (spawnedHostile)
            {
                spawnedHostile = false;
            }
        }
    }
    public void GenerateChunk()
    {
        //noise.SetSeed(world.World_Seed);
        noise.SetNoiseType(FastNoiseLite.NoiseType.OpenSimplex2);
        noise.SetSeed(world.World_Seed);

        vertices = new Vector3[(ChunkSizeX + 1) * (ChunkSizeY + 1)];
        triangles = new int[(ChunkSizeX * ChunkSizeY) * 6];

        //Vertices
        int i = 0;
        for (int x = 0; x <= ChunkSizeX; x++)
        {
            for (int y = 0; y <= ChunkSizeY; y++)
            {
                int height_posx = Mathf.RoundToInt(transform.position.x + x);
                int height_posy = Mathf.RoundToInt(transform.position.z + y);
                //float height = world.World_TerrainNoise.GetPixel(height_posx, height_posy).grayscale * 20;
                float height = GetNoiseHeight(height_posx, height_posy);
                vertices[i] = new Vector3(x, height, y);
                i++;
            }
        }
        //Triangles
        int vert = 0;
        int tris = 0;
        for (int y = 0; y < ChunkSizeY; y++)
        {
            for (int x = 0; x < ChunkSizeX; x++)
            {
                triangles[tris + 0] = vert + 0;
                triangles[tris + 1] = vert + ChunkSizeX + 1;
                triangles[tris + 2] = vert + 1;
                triangles[tris + 3] = vert + 1;
                triangles[tris + 4] = vert + ChunkSizeX + 1;
                triangles[tris + 5] = vert + ChunkSizeX + 2;
                vert++;
                tris += 6;
            }
            vert++;
        }
    }
    public void DrawChunk()
    {
        chunkmesh.Clear();

        chunkmesh.vertices = vertices;
        chunkmesh.triangles = triangles;
        //Reverse Triangles
        chunkmesh.triangles = chunkmesh.triangles.Reverse().ToArray();
        //Recalculate Bounds/Normals
        chunkmesh.RecalculateBounds();
        chunkmesh.RecalculateNormals();

        //Reset UVs
        Vector2[] uvs = new Vector2[vertices.Length];

        for (int i = 0; i < uvs.Length; i++)
        {
            uvs[i] = new Vector2(vertices[i].x, vertices[i].z);
        }
        chunkmesh.uv = uvs;
        GetComponent<MeshRenderer>().material.SetTexture("_MainTex", world.handler.objects.Environments[world.World_CurrentEnvironment].Ground);

        //Set the collider
        GetComponent<MeshCollider>().sharedMesh = chunkmesh;
        GetComponent<MeshCollider>().sharedMesh = chunkmesh;
    }
    public void GenerateObjects()
    {
        //Objects
        rand = new Random(Mathf.RoundToInt(world.World_Seed + (transform.position.x / 16 * transform.position.z / 16)));
        for (int x = 0; x <= ChunkSizeX; x++)
        {
            for (int y = 0; y <= ChunkSizeY; y++)
            {
                float ix = transform.position.x + x;
                float iy = transform.position.z + y;
                float scale = world.handler.objects.Environments[world.World_CurrentEnvironment].ObjectSpawnChance * 0.25f;
                float seedOffset = world.World_Seed * 0.000001f;
                if (Mathf.PerlinNoise(ix * 0.25f + seedOffset, iy * 0.25f + seedOffset) <= scale)
                {
                    if (Physics.Raycast(new Vector3(ix, 500, iy), -transform.up, out RaycastHit hit))
                    {
                        if (hit.transform.gameObject == gameObject)
                        {
                            int objectToSpawn = getObjectRandomize();
                            //int objectToSpawn = Random.Range(0, world.handler.objects.Environments[world.World_CurrentEnvironment].SpawnableObjects.Length);
                            GameObject g = Instantiate(world.handler.objects.Environments[world.World_CurrentEnvironment].SpawnableObjects[objectToSpawn].Object, hit.point, Quaternion.Euler(0, rand.Next(-179, 179), 0));
                            g.transform.parent = transform;
                        }
                    }
                }
            }
        }
    }
    public void SpawnPassiveMobs() 
    {
        if (world.handler.objects.Environments[world.World_CurrentEnvironment].PassiveMobs.Length != 0)
        {
            int amount = UnityEngine.Random.Range(-1, 2);
            for (int i = 0; i < amount; i++)
            {
                Vector3 spawnPos = new Vector3(0, 0, 0);
                spawnPos = transform.position + vertices[UnityEngine.Random.Range(0, vertices.Length)] + new Vector3(0, 1, 0);
                Instantiate(getPassiveNPCRandom(), spawnPos, Quaternion.identity);
            }
        }
    }
    public void SpawnHostileMobs()
    {
        if (world.handler.objects.Environments[world.World_CurrentEnvironment].HostileMobs.Length != 0)
        {
            int amount = UnityEngine.Random.Range(0, 2);
            for (int i = 0; i < amount; i++)
            {
                Vector3 spawnPos = new Vector3(0, 0, 0);
                spawnPos = transform.position + vertices[UnityEngine.Random.Range(0, vertices.Length)] + new Vector3(0, 1, 0);
                Instantiate(getHostileNPCRandom(), spawnPos, Quaternion.identity);
            }
        }
        spawnedHostile = true;
    }
    //Generation Return
    public float GetNoiseHeight(int x, int z)
    {
        float worldHeight = world.handler.objects.Environments[world.World_CurrentEnvironment].HeightMultiplier * 0.1f;

        float simplex1 = noise.GetNoise(x * .8f, z * .8f) * worldHeight;
        float simplex2 = noise.GetNoise(x * 3f, z * 3f) * worldHeight * (noise.GetNoise(x * .3f, z * .3f) + .5f);

        //Generate a Psuedo-Random height from 3 areas of varying height
        float height = simplex1 + simplex2;
        //Debug.Log(height + ", sim1 " + simplex1 + ", sim2 " + simplex2);
        return height;
    }
    public int getObjectRandomize()
    {
        // Get the total sum of all the weights.

        List<int> weights = new List<int>();
        int weightSum = 0;
        for (int i = 0; i < world.handler.objects.Environments[world.World_CurrentEnvironment].SpawnableObjects.Length; ++i)
        {
            weights.Add(world.handler.objects.Environments[world.World_CurrentEnvironment].SpawnableObjects[i].Probability * 10);
            weightSum += world.handler.objects.Environments[world.World_CurrentEnvironment].SpawnableObjects[i].Probability * 10;
        }

        // Step through all the possibilities, one by one, checking to see if each one is selected.
        int index = 0;
        int lastIndex = weights.Count - 1;
        while (index < lastIndex)
        {
            // Do a probability check with a likelihood of weights[index] / weightSum.
            if (rand.Range(0, weightSum) < weights[index])
            {
                return index;
            }

            // Remove the last item from the sum of total untested weights and try again.
            weightSum -= weights[index++];
        }

        // No other item was selected, so return very last index.
        return index;
    }
    public GameObject getPassiveNPCRandom() 
    {
        return world.handler.objects.Environments[world.World_CurrentEnvironment].PassiveMobs[ UnityEngine.Random.Range(0, world.handler.objects.Environments[world.World_CurrentEnvironment].PassiveMobs.Length)];
    }
    public GameObject getHostileNPCRandom()
    {
        return world.handler.objects.Environments[world.World_CurrentEnvironment].HostileMobs[UnityEngine.Random.Range(0, world.handler.objects.Environments[world.World_CurrentEnvironment].HostileMobs.Length)];
    }
}