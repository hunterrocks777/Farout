﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity_DestroyInSeconds : MonoBehaviour
{
    public float timer = 1;

    public void SetTimer(float time) 
    {
        Invoke("destroyMyself", time);
    }

    void destroyMyself() 
    {
        Destroy(gameObject);
    }
}
