﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity_HeatSource : MonoBehaviour
{
    public int heat_temperature;
}
