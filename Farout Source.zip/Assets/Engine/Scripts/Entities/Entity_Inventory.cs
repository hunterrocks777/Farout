﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class Entity_Inventory : MonoBehaviour
{
    public int[] Inventory = new int[36];
    public bool Inventory_RandomizedLoot = false;
    public bool Inventory_NewItem(int ID)
    {
        for (int i = 0; i < Inventory.Length; i++)
        {
            if (Inventory[i] == 0) 
            {
                Inventory[i] = ID;
                return true;
            }
        }
        return false;
    }
    public void Inventory_DeleteItem(int ID) 
    {
        Inventory[ID] = 0;
    }
    public void Inventory_Reset() 
    {
        Inventory = new int[36];
    }
    public void Inventory_RandomizeLoot() 
    {
        Handler_Gamehandler handler = FindObjectOfType<Handler_Gamehandler>();
        UnityEngine.Random.InitState(handler.world.World_Seed);
        for (int i = 0; i < Inventory.Length; i++)
        {
            Inventory[i] = UnityEngine.Random.Range(0, handler.objects.Items.Length);
        }
    }
    //Functions
    public void Inventory_UseItem(int ID)
    {
        FindObjectOfType<Entity_Player>().CurrentItem = ID;
    }
    public void Inventory_DropItem(int ID) 
    {
        FindObjectOfType<Handler_Gamehandler>().Game_CreateItem(Inventory[ID], transform.position + transform.forward * 2);
        Inventory_DeleteItem(ID);
    }
    public void Inventory_Sort() 
    {
        int i = 0;
        int[] oldInv = Inventory;
        Inventory = new int[36];
        foreach (int a in oldInv.OrderByDescending(Inventory => Inventory))
        {
            Inventory[i] = a;
            i++;
        }
    }
}
