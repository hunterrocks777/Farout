﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity_Destructable : MonoBehaviour
{
    public string Entity_Type;
    public int Entity_HP = 50;
    public ScriptableObject[] MaterialsDropped = new ScriptableObject[0];
    [HideInInspector] public int[] Entity_Materials = new int[0];
    Handler_Gamehandler handler;
    private void Start()
    {
        if (MaterialsDropped.Length != 0)
        {
            Entity_Materials = new int[MaterialsDropped.Length];
            handler = FindObjectOfType<Handler_Gamehandler>();
            for (int i = 0; i < MaterialsDropped.Length; i++)
            {
                Entity_Materials[i] = handler.objects.getItemID(MaterialsDropped[i]);
            }
        }
    }
    public void HurtEntity(int dmg, string type)
    {
        if (type == "axe" && Entity_Type == "wood")
        {
            Entity_HP -= dmg;
        }
        else
        {
            if (type == "pickaxe" && Entity_Type == "ore")
            {
                Entity_HP -= dmg;
            }
            else
            {
                if (Entity_Type == "")
                {
                    Entity_HP -= dmg;
                }
                else
                {
                    Entity_HP -= dmg / 2;
                }
            }
        }
    }
    private void Update()
    {
        if (Entity_HP <= 0)
        {
            if (Entity_Materials.Length != 0) 
            {
                for (int i = 0; i < Entity_Materials.Length; i++)
                {
                    handler.Game_CreateEffect_DestructionParticle(transform.position, (Texture2D)GetComponent<MeshRenderer>().material.mainTexture);
                    handler.Game_CreateItem(Entity_Materials[i], transform.position + new Vector3(Random.Range(-0.25f, 0.25f) * i, 0, Random.Range(-0.25f, 0.25f) * i));
                }
            }
            Destroy(gameObject);
        }
    }
}
