﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity_Player : MonoBehaviour
{
    public int Player_Health_Max = 100;
    public int Player_Stamina_Max = 100;
    public int Player_Health = 100;
    public float Player_Stamina = 100;
    public float Player_Hunger = 100;
    public int Player_DefaultFOV = 90;
    [HideInInspector] public int Player_Camera_FOV = 90;
    [HideInInspector] public bool Player_Stamina_CanUse = true;
    [HideInInspector] public float Player_Health_RecentDamage = 0;

    [HideInInspector] public string LookAt_Name;

    public float Player_Speed_Walk = 5;
    public float Player_Speed_Jump = 15;

    [HideInInspector] public Vector2 Player_LookRot;
    [HideInInspector] public Vector3 Player_Velocity;
    public int Player_ActualTempurature;
    [HideInInspector] public int Player_BodyTempurature;
    [HideInInspector] public int Player_EnvironmentTempurature;

    [HideInInspector] public int CurrentItem = 0;
    [HideInInspector] public Entity_Inventory MyInventory;

    [HideInInspector] public CharacterController Player_Controller;
    public GameObject Player_Viewmodel;
    public GameObject Player_Camera;
    public GameObject Player_Weapon;

    [HideInInspector] public bool canAttack = true;
    Handler_Gamehandler handler;
    void Start()
    {
        canAttack = true;
        handler = FindObjectOfType<Handler_Gamehandler>();
        Player_Controller = GetComponent<CharacterController>();
    }
    public void Player_Reset() 
    {
        Player_Health = 100;
        Player_Health_Max = 100;
        Player_Health_RecentDamage = 0;
        Player_Stamina = 100;
        Player_Stamina_Max = 100;
        Player_Stamina_CanUse = true;
        Player_Hunger = 100;
        Player_LookRot = new Vector2(0, 0);
        Player_Velocity = new Vector3(0, 0, 0);
        MyInventory.Inventory_Reset();
    }
    public void Player_Teleport(Vector3 pos) 
    {
        Player_Controller.enabled = false;
        for (int i = 0; i < 100; i++)
        {
            transform.position = pos;
            Player_Velocity = new Vector3(0, 0, 0);
        }
        Player_Controller.enabled = true;
    }
    void Update()
    {
        if (handler.World_UIScreen != "mainmenu" && handler.World_UIScreen != "loading" && !handler.World_Paused && Player_Health > 0)
        {
            Player_Movement();
            Player_Look();
            Player_Combat();
            Player_TempuratureCheck();
            Player_LookAt();
            //Stamina
            if (Input.GetKey(KeyCode.LeftShift) && Player_Velocity.x != 0 && Player_Velocity.z != 0 && Player_Stamina_CanUse)
            {
                Player_Stamina -= Time.deltaTime * 20;
            }
            else
            {
                Player_Stamina += Time.deltaTime * 20;
            }
            if (Player_Stamina <= 0) 
            {
                Player_Stamina_CanUse = false;
            }
            if(Player_Stamina >= Player_Stamina_Max) 
            {
                Player_Stamina_CanUse = true;
            }
            Player_Health = Mathf.Clamp(Player_Health, 0, Player_Health_Max);
            Player_Stamina = Mathf.Clamp(Player_Stamina, 0, Player_Stamina_Max);
            //Hunger
            Player_Hunger -= Time.deltaTime * 0.25f;
            Player_Hunger = Mathf.Clamp(Player_Hunger, 0, 100);
            if (handler.World_Tick <= 0.025f)
            {
                if (Player_Hunger <= 0)
                {
                    Player_Health -= 1;
                    Player_Health_RecentDamage = 10;
                }
            }
            Player_Health_RecentDamage -= Time.deltaTime * 0.5f;
        }
    }
    void Player_Movement() 
    {
        float velocity_oldy = Player_Velocity.y;
        Player_Velocity = (transform.forward * Input.GetAxis("Vertical") * Player_Movement_GetSpeed()) + (transform.right * Input.GetAxis("Horizontal") * Player_Movement_GetSpeed());
        Player_Velocity.y = velocity_oldy;
        if (Player_Controller.isGrounded) 
        {
            Player_Velocity.y = 0;
            if (Input.GetKey(KeyCode.Space)) 
            {
                handler.sound.createAudioClipLibrary("jump", transform.position);
                Player_Velocity.y = Player_Speed_Jump;
            }
        }
        Player_Velocity += Physics.gravity * Time.deltaTime;

        Player_Controller.Move(Player_Velocity * Time.deltaTime);
    }
    float Player_Movement_GetSpeed() 
    {
        if (Input.GetKey(KeyCode.LeftShift) && Player_Stamina_CanUse)
        {
            return Player_Speed_Walk * 1.75f;
        }
        return Player_Speed_Walk;
    }
    void Player_Look() 
    {
        Player_LookRot.x -= Input.GetAxis("Mouse Y") * handler.prefs.Prefs.Gameplay_MouseSpeed;
        Player_LookRot.x = Mathf.Clamp(Player_LookRot.x, -90, 90);
        Player_LookRot.y += Input.GetAxis("Mouse X") * handler.prefs.Prefs.Gameplay_MouseSpeed;

        transform.localRotation = Quaternion.Euler(new Vector3(0, Player_LookRot.y, 0));
        Player_Viewmodel.transform.localRotation = Quaternion.Euler(new Vector3(Player_LookRot.x, 0, 0));
        Player_Camera.GetComponent<Camera>().fieldOfView = Mathf.Lerp(Player_Camera.GetComponent<Camera>().fieldOfView, Player_Camera_FOV, 0.5f);
        if (Player_Velocity.magnitude >= Player_Speed_Walk * 1.75f) 
        {
            Player_Camera_FOV = Player_DefaultFOV + 10;
        }
        else 
        {
            Player_Camera_FOV = Player_DefaultFOV;
        }
    }
    void Player_LookAt() 
    {
        if (canAttack)
        {
            LookAt_Name = "";
            RaycastHit hit = new RaycastHit();
            Ray ray = new Ray(Player_Camera.transform.position, Player_Camera.transform.forward);
            if (Physics.Raycast(ray, out hit, 6))
            {
                if (hit.transform.GetComponent<Entity_Pickup>())
                {
                    LookAt_Name = "Pickup " + handler.objects.Items[hit.transform.GetComponent<Entity_Pickup>().ID].name;
                    if (Input.GetKeyDown(KeyCode.E))
                    {
                        hit.transform.GetComponent<Entity_Pickup>().Item_Pickup(this);
                    }
                }
                if (hit.transform.GetComponent<Entity_Bed>())
                {
                    LookAt_Name = "Sleep till 6 AM";
                    if (Input.GetKeyDown(KeyCode.E))
                    {
                        hit.transform.GetComponent<Entity_Bed>().Bed_Sleep();
                    }
                }
            }
        }
    }
    void Player_TempuratureCheck()
    {
        int heatTemp = 0;
        Collider[] stuff = Physics.OverlapSphere(transform.position, 10);
        foreach (Collider coll in stuff)
        {
            Entity_HeatSource heat = coll.GetComponent<Entity_HeatSource>();
            if (heat)
            {
                heatTemp = heat.heat_temperature;
                break;
            }
        }
        int envtemp;
        Ray ray = new Ray(transform.position + -handler.world.Sun.transform.forward * 10, handler.world.Sun.transform.forward);

        if (Physics.Raycast(ray, out RaycastHit hit, 8) && hit.transform != transform && handler.world.Sun.Time_Multiplier == 1)
        {
            envtemp = Mathf.RoundToInt(handler.world.World_EnvironmentTemp * 0.75f);
        }
        else
        {
            envtemp = (int)handler.world.World_EnvironmentTemp;
        }

        Player_ActualTempurature = envtemp + heatTemp + Player_BodyTempurature;

        if (handler.World_Tick <= 0.025f)
        {
            if (Player_ActualTempurature >= 85 || Player_ActualTempurature <= 15)
            {
                Player_Health -= 1;
                Player_Health_RecentDamage = 5;
            }
        }
    }
    void Player_Combat()
    {
        if (canAttack)
        {
            CurrentItem += (int)Input.GetAxis("Mouse ScrollWheel");
            CurrentItem = Mathf.Clamp(CurrentItem, 0, 35);
        }
        ScriptableObject item = handler.objects.Items[MyInventory.Inventory[CurrentItem]];
        if (item is Object_Weapon)
        {
            Object_Weapon weapon = (Object_Weapon)item;
            Player_Weapon.GetComponent<MeshFilter>().mesh = weapon.Mesh;
            Player_Weapon.GetComponent<MeshRenderer>().material.mainTexture = weapon.Texture;
            if (Player_Weapon.GetComponent<Light>())
            {
                Player_Weapon.GetComponent<Light>().color = weapon.WeaponEmitance;
                Player_BodyTempurature = weapon.WeaponHeat;
            }
            if (Input.GetKey(KeyCode.Mouse0) && canAttack)
            {
                Player_Combat_Attack();
            }
            //Animations
            if (canAttack) 
            {
                Player_Viewmodel.GetComponent<Animator>().Play(weapon.Animation_Idle);
            }
            else 
            {
                Player_Viewmodel.GetComponent<Animator>().Play(weapon.Animation_Attack);
            }
        }
        if (item is Object_Item)
        {
            Player_BodyTempurature = 0;
            Object_Item a = (Object_Item)item;
            Player_Weapon.GetComponent<MeshFilter>().mesh = a.Mesh;
            Player_Weapon.GetComponent<MeshRenderer>().material.mainTexture = a.Texture;
            if (Player_Weapon.GetComponent<Light>())
            {
                Player_Weapon.GetComponent<Light>().color = Color.black;
            }
            if (Input.GetKey(KeyCode.Mouse0) && canAttack)
            {
                Player_Combat_Attack();
            }
            //Animations
            if (canAttack)
            {
                Player_Viewmodel.GetComponent<Animator>().Play("fist_idle");
            }
            else
            {
                Player_Viewmodel.GetComponent<Animator>().Play("fist_attack");
            }
        }
        if (item is Object_Consumable)
        {
            Player_BodyTempurature = 0;
            Object_Consumable a = (Object_Consumable)item;
            Player_Weapon.GetComponent<MeshFilter>().mesh = a.Mesh;
            Player_Weapon.GetComponent<MeshRenderer>().material.mainTexture = a.Texture;
            if (Player_Weapon.GetComponent<Light>())
            {
                Player_Weapon.GetComponent<Light>().color = Color.black;
            }
            if (Input.GetKey(KeyCode.Mouse0) && canAttack)
            {
                Player_Combat_Consume();
            }
            //Animations
            if (canAttack)
            {
                Player_Viewmodel.GetComponent<Animator>().Play("consumable_idle");
            }
            else
            {
                Player_Viewmodel.GetComponent<Animator>().Play("consumable_consume");
            }
        }
        if (item is Object_Buildable)
        {
            Player_BodyTempurature = 0;
            Object_Buildable a = (Object_Buildable)item;
            Player_Weapon.GetComponent<MeshFilter>().mesh = null;
            Player_Weapon.GetComponent<MeshRenderer>().material.mainTexture = null;
            if (Player_Weapon.GetComponent<Light>())
            {
                Player_Weapon.GetComponent<Light>().color = Color.black;
            }
            if (Input.GetKey(KeyCode.Mouse0) && canAttack)
            {
                Player_Combat_Build();
            }
            //Animations
            if (canAttack)
            {
                Player_Viewmodel.GetComponent<Animator>().Play("fist_idle");
            }
            else
            {
                Player_Viewmodel.GetComponent<Animator>().Play("fist_attack");
            }
        }
    }
    void Player_Combat_Attack()
    {
        ScriptableObject item = handler.objects.Items[MyInventory.Inventory[CurrentItem]];
        int dist = 2;
        int dmg = 5;
        string type = "";
        float atkinterval = 0.5f;
        if (item is Object_Weapon)
        {
            Object_Weapon weapon = (Object_Weapon)item;
            atkinterval = weapon.AttackInterval;
            dmg = weapon.AttackDamage;
            dist = weapon.AttackRange;
            type = weapon.Weapon_Type;
            if (weapon.Audio_Attack)
            {
                handler.sound.createAudioClip(weapon.Audio_Attack, transform.position);
            }
            canAttack = false;
        }
        else 
        {
            handler.sound.createAudioClipLibrary("swing", transform.position);
            atkinterval = 0.5f;
            dmg = 5;
            dist = 2;
            canAttack = false;
            //Function
        }
        RaycastHit hit = new RaycastHit();
        Ray ray = new Ray(Player_Camera.transform.position, Player_Camera.transform.forward);
        if (Physics.Raycast(ray, out hit, dist))
        {
            handler.sound.createAudioClipLibrary("hit", hit.point);
            Entity_Destructable destruc = hit.transform.GetComponent<Entity_Destructable>();
            Entity_NPC npc = hit.transform.GetComponent<Entity_NPC>();
            if (destruc)
            {
                destruc.HurtEntity(dmg, type);
                if (hit.transform.GetComponent<MeshRenderer>())
                {
                    handler.Game_CreateEffect_BreakParticle(hit.point, (Texture2D)hit.transform.GetComponent<MeshRenderer>().material.mainTexture);
                }
            }
            if (npc)
            {
                npc.NPC_Hurt(Mathf.RoundToInt(dmg / handler.prefs.Prefs.Gameplay_Difficulty), gameObject);
                handler.Game_CreateEffect("effect_blood", hit.point);
            }
        }
        //Invoke a function to allow the player to fire again
        Invoke("Player_Combat_Attack_AttackEnd", atkinterval);
    }
    void Player_Combat_Attack_AttackEnd() 
    {
        canAttack = true;
    }
    public void Player_Hurt(int amount) 
    {
        Player_Health -= amount;
        Player_Health_RecentDamage = amount * 0.75f;
    }
    void Player_Combat_Consume()
    {
        canAttack = false;
        Invoke("Player_Combat_Consume_End", 1);
    }
    void Player_Combat_Consume_End()
    {
        Object_Consumable consumable = (Object_Consumable) handler.objects.Items[MyInventory.Inventory[CurrentItem]];

        if (consumable.Consumable_Effect == "health")
        {
            Player_Health += consumable.Consumable_EffectAddition;
            if(consumable.Consumable_EffectAddition <= 0) 
            {
                Player_Health_RecentDamage = -consumable.Consumable_EffectAddition;
            }
        }
        if (consumable.Consumable_Effect == "stamina")
        {
            Player_Stamina += consumable.Consumable_EffectAddition;
        }
        if (consumable.Consumable_Effect == "maxhealth")
        {
            Player_Health_Max += consumable.Consumable_EffectAddition;
        }
        if (consumable.Consumable_Effect == "maxstamina")
        {
            Player_Stamina_Max += consumable.Consumable_EffectAddition;
        }
        if (consumable.Consumable_Effect == "food")
        {
            Player_Hunger += consumable.Consumable_EffectAddition;
        }
        MyInventory.Inventory_DeleteItem(CurrentItem);
        canAttack = true;
    }
    void Player_Combat_Build()
    {
        canAttack = false;
        RaycastHit hit = new RaycastHit();
        Ray ray = new Ray(Player_Camera.transform.position, Player_Camera.transform.forward);
        if (Physics.Raycast(ray, out hit, 10))
        {
            if (!hit.transform.GetComponent<Entity_NPC>())
            {
                handler.Game_CreateBuildable(MyInventory.Inventory[CurrentItem], hit.point + new Vector3(0, 0.2f, 0), hit.transform.gameObject);
                MyInventory.Inventory_DeleteItem(CurrentItem);
            }
        }
    }
}
