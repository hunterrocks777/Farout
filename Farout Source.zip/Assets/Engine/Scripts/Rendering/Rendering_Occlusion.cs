﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rendering_Occlusion : MonoBehaviour
{
    Camera MainCamera;
    MeshRenderer c_meshrenderer;
    private void Start()
    {
        MainCamera = FindObjectOfType<Camera>();
        c_meshrenderer = GetComponent<MeshRenderer>();
    }
    void Update()
    {
        Vector3 point = MainCamera.WorldToViewportPoint(transform.position);
        bool render = point.z > 0;

        if (render) 
        {
            //c_meshrenderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On;
        }
        else 
        {
            //c_meshrenderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.ShadowsOnly;
        }
    }
}
