﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Entity_RenderTexture : MonoBehaviour
{
    public Texture _MainTex;
    [Range(0.00f, 1.00f)] public float _Glossiness;
    [Range(0.00f, 1.00f)] public float _Metallic;
    void Start()
    {
        MeshRenderer render = GetComponent<MeshRenderer>();
        SkinnedMeshRenderer skinrender = GetComponent<SkinnedMeshRenderer>();
        if (render)
        {
            render.material.SetTexture("_MainTex", _MainTex);
            render.material.SetFloat("_Metallic", _Metallic);
            render.material.SetFloat("_Glossiness", _Glossiness);
        }
        if (skinrender) 
        {
            skinrender.material.SetTexture("_MainTex", _MainTex);
            skinrender.material.SetFloat("_Metallic", _Metallic);
            skinrender.material.SetFloat("_Glossiness", _Glossiness);
        }
    }
}
