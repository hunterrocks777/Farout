﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Handler_ObjectHandler : MonoBehaviour
{
    public ScriptableObject[] Items;
    public Object_Blueprint[] Blueprints;
    public Object_Environment[] Environments;

    public int getItemID(ScriptableObject obj)
    {
        for (int i = 0; i < Items.Length; i++)
        {
            if (Items[i] == obj) 
            {
                return i;
            }
        }
        return 0;
    }
    public int getBlueprintID(Object_Blueprint obj)
    {
        for (int i = 0; i < Blueprints.Length; i++)
        {
            if (Blueprints[i] == obj)
            {
                return i;
            }
        }
        return 0;
    }
}