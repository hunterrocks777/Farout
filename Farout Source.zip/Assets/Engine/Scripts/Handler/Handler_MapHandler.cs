﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Handler_MapHandler : MonoBehaviour
{
    public int World_CurrentEnvironment;
    public int World_Seed = 57357546; //The seed of the world
    public int World_ChunkDist = 3; // How many chunks can be rendered
    bool World_Render;

    //Temperature
    public int World_EnvironmentTemp;
    public int World_WeatherTemp;
    public bool World_TempCool;

    [HideInInspector] public GameObject Player;
    [HideInInspector] public Entity_Sun Sun;

    [HideInInspector] public static Dictionary<Map_ChunkPos, Map_Chunk> chunks = new Dictionary<Map_ChunkPos, Map_Chunk>();
    [HideInInspector] public List<Map_ChunkPos> ChunksPooled;
    public GameObject ChunkPrefab;
    [HideInInspector] public Vector3 CurChunk = new Vector3(-1, 0, -1);

    [HideInInspector] public Handler_Gamehandler handler;

    private void Start()
    {
        Player = FindObjectOfType<Entity_Player>().gameObject;
        handler = FindObjectOfType<Handler_Gamehandler>();
        Sun = FindObjectOfType<Entity_Sun>();
    }
    private void Update()
    {
        if (World_Render && handler.World_UIScreen != "mainmenu" && handler.World_UIScreen != "loading")
        {
            if (Sun.Time_Time <= 14 && Sun.Time_Time >= 10)
            {
                World_EnvironmentTemp = handler.objects.Environments[World_CurrentEnvironment].GlobalTemprature + 10;
            }
            else 
            {
                if (Sun.Time_Time <= 18 && Sun.Time_Time >= 6) 
                {
                    World_EnvironmentTemp = handler.objects.Environments[World_CurrentEnvironment].GlobalTemprature;
                }
                else 
                {
                    World_EnvironmentTemp = handler.objects.Environments[World_CurrentEnvironment].GlobalTemprature - 20;
                }
            }
            UpdateChunks();
        }
    }
    public void NewWorld(int environment, int seed)
    {
        World_Render = true;
        //Reset Player's Current Chunk
        CurChunk = new Vector3(-1, 0, -1);
        Player.GetComponent<Entity_Player>().Player_Reset();
        Player.GetComponent<Entity_Player>().Player_Teleport(new Vector3(0, 50, 0));
        UpdateChunks();
        //Set the world variables
        World_CurrentEnvironment = environment;
        World_Seed = seed;
        World_EnvironmentTemp = handler.objects.Environments[World_CurrentEnvironment].GlobalTemprature;
        Random.InitState(seed);
        Sun.Time_Time = 6;

        RenderSettings.skybox = handler.objects.Environments[World_CurrentEnvironment].Skybox;
        Sun.GetComponent<Light>().color = handler.objects.Environments[World_CurrentEnvironment].Light_Color;
        RenderSettings.fogColor = handler.objects.Environments[World_CurrentEnvironment].Fog_Color;
        RenderSettings.fogDensity = handler.objects.Environments[World_CurrentEnvironment].Fog_Density;
        Invoke("setPlayer", 1f);
    }
    void setPlayer() 
    {
        Physics.Raycast(new Vector3(0, 300, 0), -transform.up, out RaycastHit hit, 300, 1 >> 8);
        Player.GetComponent<Entity_Player>().Player_Teleport(hit.point + new Vector3(0, 1, 0));
        Debug.Log("Point hit at: " + hit.point);
        handler.World_UIScreen = "hud";
    }
    public void DestroyWorld() 
    {
        World_Render = false;
        handler.UpdateUIScreen("mainmenu");
        Invoke("DestroyChunks", 1);
        Entity_NPC[] npc = FindObjectsOfType<Entity_NPC>();
        Entity_Pickup[] items = FindObjectsOfType<Entity_Pickup>();
        foreach (Entity_NPC c in npc)
        {
            Destroy(c.gameObject);
        }
        foreach (Entity_Pickup c in items)
        {
            Destroy(c.gameObject);
        }
    }
    void DestroyChunks() 
    {
        Map_Chunk[] Chunks = new Map_Chunk[chunks.Count];
        chunks.Values.CopyTo(Chunks, 0);
        foreach (Map_Chunk c in Chunks)
        {
            Destroy(c.gameObject);
        }
        chunks.Clear();
    }
    public void UpdateChunks() 
    {
        //Update Player Chunk Pos
        float CurChunkX = Mathf.FloorToInt(Player.transform.position.x / 16) * 16;
        float CurChunkZ = Mathf.FloorToInt(Player.transform.position.z / 16) * 16;

        //Did we enter a new chunk?
        if (CurChunk.x != CurChunkX || CurChunk.z != CurChunkZ)
        {
            CurChunk.x = CurChunkX;
            CurChunk.z = CurChunkZ;
            //Load New Chunks
            for (int x = (int)CurChunkX - 16 * World_ChunkDist; x <= CurChunkX + 16 * World_ChunkDist; x += 16)
            {
                for (int z = (int)CurChunkZ - 16 * World_ChunkDist; z <= CurChunkZ + 16 * World_ChunkDist; z += 16)
                {
                    Map_ChunkPos cp = new Map_ChunkPos(x, z);

                    if (!chunks.ContainsKey(cp)) 
                    {
                        GameObject chunkObj = Instantiate(ChunkPrefab, new Vector3(x, 0, z), Quaternion.identity);
                        chunks.Add(cp, chunkObj.GetComponent<Map_Chunk>());
                    }
                    else 
                    {
                        chunks[cp].gameObject.SetActive(true);
                    }
                }
            }
            //Unload Far Away Chunks
            List<Map_ChunkPos> toDestroy = new List<Map_ChunkPos>();
            foreach (KeyValuePair<Map_ChunkPos, Map_Chunk> c in chunks)
            {
                Map_ChunkPos cp = c.Key;
                if (Mathf.Abs(CurChunkX - cp.x) > 16 * World_ChunkDist || Mathf.Abs(CurChunkZ - cp.z) > 16 * World_ChunkDist)
                {
                    toDestroy.Add(c.Key);
                }
            }
            foreach (Map_ChunkPos cp in toDestroy)
            {
                chunks[cp].gameObject.SetActive(false);
                //chunks.Remove(cp);
            }
        }
    }
}
public struct Map_ChunkPos
{
    public int x, z;
    public Map_ChunkPos(int x, int z)
    {
        this.x = x;
        this.z = z;
    }
}