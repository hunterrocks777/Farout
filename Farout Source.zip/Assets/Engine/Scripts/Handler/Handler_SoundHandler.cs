﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Handler_SoundHandler : MonoBehaviour
{
    public AudioSource Audio_Music;
    public GameObject Audio_SoundPrefab;
    public AudioClip[] AudioLibrary;

    public void createAudioClipLibrary(string name, Vector3 pos)
    {
        for (int sound = 0; sound < AudioLibrary.Length; sound++) 
        {
            if (AudioLibrary[sound].name == name)
            {
                Debug.Log(AudioLibrary[sound].name + ", "+ AudioLibrary[sound].length + 1);
                createAudioClip(AudioLibrary[sound], pos);
                break;
            }
        }
    }

    public void createAudioClip(AudioClip clip, Vector3 pos)
    {
        GameObject sound = Instantiate(Audio_SoundPrefab, pos, Quaternion.identity);
        AudioSource source = sound.GetComponent<AudioSource>();
        Entity_DestroyInSeconds timer = sound.GetComponent<Entity_DestroyInSeconds>();
        if (source)
        {
            source.volume = (float) FindObjectOfType<Handler_PlayerPrefs>().Prefs.Audio_Effects / 100;
            source.clip = clip;
            source.Play();
        }
        if (timer) 
        {
            timer.SetTimer(clip.length + 1);
        }
    }
}
