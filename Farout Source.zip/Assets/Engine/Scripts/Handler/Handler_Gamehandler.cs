﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Handler_Gamehandler : MonoBehaviour
{
    public string World_UIScreen = "mainmenu";
    public bool World_Paused = false;
    bool UI_AllowInputs = true;

    public float World_Tick;

    public GameObject[] Effects;
    public GameObject blankGO;

    [HideInInspector] public Handler_MapHandler world;
    [HideInInspector] public Handler_ObjectHandler objects;
    [HideInInspector] public Handler_SoundHandler sound;
    [HideInInspector] public Handler_PlayerPrefs prefs;
    [HideInInspector] public UI_Screens screens;
    private void Start()
    {
        World_Tick = 2;
        UI_AllowInputs = true;
        world = FindObjectOfType<Handler_MapHandler>();
        objects = FindObjectOfType<Handler_ObjectHandler>();
        sound = FindObjectOfType<Handler_SoundHandler>();
        prefs = FindObjectOfType<Handler_PlayerPrefs>();
    }
    private void Update()
    {
        World_Tick_Function();
        UI_Functions();
    }
    public void UI_Functions()
    {
        if (World_UIScreen == "mainmenu")
        {
            World_Paused = false;
            Cursor.visible = true;
            Cursor.lockState = CursorLockMode.None;
        }
        if (World_UIScreen == "hud")
        {
            World_Paused = false;
            if (world.Player.GetComponent<Entity_Player>().Player_Health > 0)
            {
                Cursor.lockState = CursorLockMode.Locked;
                Cursor.visible = false;
            }
            else 
            {
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
            }
            if (Input.GetKeyDown(KeyCode.Tab) && UI_AllowInputs) 
            {
                FindObjectOfType<UI_Inventory>().Inventory_Reset();
                UpdateUIScreen("inventory");
            }
            if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P))
            {
                if (UI_AllowInputs)
                {
                    UpdateUIScreen("pausemenu");
                }
            }
        }
        if (World_UIScreen == "pausemenu")
        {
            World_Paused = true;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P))
            {
                if (UI_AllowInputs)
                {
                    UpdateUIScreen("hud");
                }
            }
        }
        if (World_UIScreen == "inventory")
        {
            World_Paused = true;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            if (Input.GetKeyDown(KeyCode.Tab) && UI_AllowInputs)
            {
                FindObjectOfType<UI_Inventory>().Inventory_Reset();
                UpdateUIScreen("hud");
            }
        }
        if (World_UIScreen == "crafting")
        {
            World_Paused = true;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            if (Input.GetKeyDown(KeyCode.Tab) && UI_AllowInputs)
            {
                FindObjectOfType<UI_Inventory>().Inventory_Reset();
                UpdateUIScreen("hud");
            }
        }
        if (World_UIScreen == "loading")
        {
            World_Paused = false;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }
    }
    public void Game_Quit() 
    {
        Application.Quit();
    }
    public void World_Tick_Function() 
    {
        World_Tick -= Time.deltaTime;
        if (World_Tick <= 0)
        {
            World_Tick = 2;
            Debug.Log("Tick reset");
        }
    }
    public void UpdateUIScreen(string newScreen) 
    {
        UI_AllowInputs = false;
        World_UIScreen = newScreen;
        Invoke("allowUIInputs", 0.1f);
    }
    void allowUIInputs() 
    {
        UI_AllowInputs = true;
    }
    public GameObject Game_CreateEffect(string name, Vector3 pos)
    {
        GameObject obj = null;
        foreach (GameObject effect in Effects)
        {
            if (effect.name == name) 
            {
                obj = effect;
                break;
            }
        }
        return Instantiate(obj, pos, new Quaternion(0, 0, 0, 0));
    }
    public void Game_CreateEffect_BreakParticle(Vector3 pos, Texture2D texture)
    {
        GameObject effect = Game_CreateEffect("effect_impact", pos);

        if (texture)
        {
            effect.GetComponent<ParticleSystem>().startColor = texture.GetPixel(texture.width / 2, texture.height / 2);
        }
    }
    public void Game_CreateEffect_DestructionParticle(Vector3 pos, Texture2D texture)
    {
        GameObject effect = Game_CreateEffect("effect_destruction", pos);

        if (texture)
        {
            effect.GetComponent<ParticleSystem>().startColor = texture.GetPixel(texture.width / 2, texture.height / 2);
        }
    }
    public void Game_CreateItem(int ID, Vector3 pos)
    {
        GameObject g = Instantiate((GameObject)Resources.Load("Entity_Item"), pos, Quaternion.identity);
        g.GetComponent<Entity_Pickup>().ID = ID;
    }
    public void Game_CreateBuildable(int ID, Vector3 pos, GameObject chunk) 
    {
        Object_Buildable objec = (Object_Buildable) objects.Items[ID];
        if (objec && chunk) 
        {
            GameObject buildable = Instantiate(blankGO, pos, Quaternion.identity);
            //Create stuff
            buildable.AddComponent<Entity_Destructable>();
            buildable.AddComponent<MeshCollider>();
            //Set Variables
            buildable.GetComponent<MeshFilter>().mesh = objec.Mesh;
            buildable.GetComponent<MeshRenderer>().material.mainTexture = objec.Texture;
            buildable.GetComponent<MeshCollider>().sharedMesh = objec.Mesh;
            buildable.GetComponent<Entity_Destructable>().Entity_HP = objec.HP;

            if (objec.Temperature != 0)
            {
                buildable.AddComponent<Entity_HeatSource>();
                buildable.GetComponent<Entity_HeatSource>().heat_temperature = objec.Temperature;
            }
            if (objec.LightEmmitance != Color.black)
            {
                buildable.AddComponent<Light>();
                buildable.GetComponent<Light>().color = objec.LightEmmitance;
                buildable.GetComponent<Light>().intensity = 5;
                buildable.GetComponent<Light>().range = 20;
            }
            if (objec.Object_Effect == "bed")
            {
                buildable.AddComponent<Entity_Bed>();
            }
            buildable.AddComponent<Entity_Buildable>();
        }
    }
}
