﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;
using System.IO;

public class Handler_PlayerPrefs : MonoBehaviour
{
    
    public string PreferencesFileName = "Options.dat";
    public Game_PlayerPreferences Prefs = new Game_PlayerPreferences();
    Handler_Gamehandler handler;
    private void Start()
    {
        handler = FindObjectOfType<Handler_Gamehandler>();
        LoadPrefs();
    }

    public void SavePrefs() 
    {
        string jsonSavePath = Application.persistentDataPath + "/" + PreferencesFileName;

        string jsonData = JsonUtility.ToJson(Prefs, true);
        File.WriteAllText(jsonSavePath, jsonData);
        ApplyPrefs();
    }
    public void LoadPrefs()
    {
        string jsonSavePath = Application.persistentDataPath + "/" + PreferencesFileName;
        if (File.Exists(jsonSavePath))
        {
            Game_PlayerPreferences PrefsLoading = JsonUtility.FromJson<Game_PlayerPreferences>(File.ReadAllText(jsonSavePath));
            Prefs = PrefsLoading;
            FindObjectOfType<UI_MainMenu_Options>().SetValues();
            ApplyPrefs();
        }
    }
    public void ApplyPrefs() 
    {
        QualitySettings.SetQualityLevel(Prefs.Graphics_Quality);
        FindObjectOfType<Handler_MapHandler>().World_ChunkDist = Prefs.Graphics_ChunkDist;
        Screen.SetResolution(Prefs.Graphics_ResolutionX, Prefs.Graphics_ResolutionY, Prefs.Graphics_Fullscreen);
        FindObjectOfType<PostProcessVolume>().enabled = Prefs.Graphics_PostProcessing;
        FindObjectOfType<Handler_SoundHandler>().Audio_Music.volume = (float) Prefs.Audio_Music / 100;
    }
}
[System.Serializable]
public class Game_PlayerPreferences 
{
    public int Gameplay_MouseSpeed = 6; //Player's Mousespeed | 2 = V. Low, 4 = Low, 6 = Normal, 8 = Fast, 10 = V. Fast
    public float Gameplay_Difficulty = 2; //Game Difficulty | 0 = V. Easy, 1 = Easy, 2 = Normal, 3 = Hard, 4 = V. Hard
    public bool Gameplay_ShowHUD = true; //Enable the HUD?
    public int Graphics_Quality = 2; //Graphics Quality |0 = Potato, 1 = Low, 2 = Medium, 3 = High, 4 = Ultra
    public int Graphics_ResolutionX = 1280; //Resolution for the game
    public int Graphics_ResolutionY = 720; //Resolution for the game
    public bool Graphics_Fullscreen = true; //Render in fullscreen?
    public bool Graphics_PostProcessing = true; //Allow Post Processing
    public int Audio_Effects = 100; //SFX Volume
    public int Audio_Music = 100; //Soundtrack Volume
}