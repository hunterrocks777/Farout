﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

public class UI_Inventory_Crafting_Recipe : MonoBehaviour
{
    public int ID;

    List<int> MaterialIDs;

    Handler_Gamehandler handler;
    UI_Inventory_Crafting ui_crafting;
    Entity_Inventory player_inventory;
    private void Start()
    {
        handler = FindObjectOfType<Handler_Gamehandler>();
        ui_crafting = FindObjectOfType<UI_Inventory_Crafting>();
    }
    public void CreateRecipe() 
    {
        Handler_ObjectHandler objects = FindObjectOfType<Handler_ObjectHandler>();
        GetComponent<Image>().sprite = objects.Blueprints[ID].UI_Sprite;
        MaterialIDs = new List<int>();
        //Fill the ID of the materials required to craft
        foreach (ScriptableObject a in objects.Blueprints[ID].Materials)
        {
            MaterialIDs.Add(objects.getItemID(a));
        }
        player_inventory = FindObjectOfType<Entity_Player>().MyInventory;
    }
    private void Update()
    {
        bool appear = true;
        foreach (int a in MaterialIDs)
        {
            if (player_inventory.Inventory.Contains(a))
            {
                appear = true;
                break;
            }
            else
            {
                appear = false;
            }
        }
        GetComponent<Image>().enabled = appear;
        GetComponent<Button>().enabled = appear;
        if (appear) 
        {
            transform.SetParent(ui_crafting.UI_Inventory_Crafting_RecipeList_Content);
        }
        else 
        {
            transform.SetParent(ui_crafting.transform);
        }
    }
    public void onButtonPress() 
    {
        FindObjectOfType<UI_Inventory_Crafting>().recipeID = ID;
    }
}
