﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UI_MainMenu_Screens : MonoBehaviour
{
    public int currentScreen;
    public GameObject[] Screens;
    public void changeScreen(int news)
    {
        currentScreen = news;
    }
    void Update()
    {
        for (int i = 0; i < Screens.Length; i++)
        {
            if (currentScreen == i)
            {
                Screens[i].transform.localScale = new Vector3(1, 1, 1);
            }
            else 
            {
                Screens[i].transform.localScale = new Vector3(0, 0, 0);
            }
        }
    }
}
