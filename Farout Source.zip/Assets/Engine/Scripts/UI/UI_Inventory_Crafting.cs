﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class UI_Inventory_Crafting : MonoBehaviour
{
    public int recipeID;
    public Text Crafting_Text_ItemToCraft;
    public Text Crafting_Text_Materials;

    public RectTransform UI_Inventory_Crafting_RecipeList_Content;
    public GameObject UI_Inventory_Crafting_Recipe_Prefab;

    Handler_Gamehandler handler;
    private void Start()
    {
        handler = FindObjectOfType<Handler_Gamehandler>();
        CreateBlueprints();
    }
    public void CreateBlueprints() 
    {
        Handler_ObjectHandler objects = FindObjectOfType<Handler_ObjectHandler>();
        UI_Inventory_Crafting_RecipeList_Content.sizeDelta = new Vector2(60 + (60 * objects.Blueprints.Length), 124);
        foreach (Object_Blueprint blueprint in objects.Blueprints)
        {
            GameObject prefab = Instantiate(UI_Inventory_Crafting_Recipe_Prefab);
            prefab.transform.SetParent(UI_Inventory_Crafting_RecipeList_Content.transform);
            prefab.GetComponent<UI_Inventory_Crafting_Recipe>().ID = objects.getBlueprintID(blueprint);
            prefab.GetComponent<UI_Inventory_Crafting_Recipe>().CreateRecipe();
        }
    }
    private void Update()
    {
        UI_Inventory_Crafting_RecipeList_Content.sizeDelta = new Vector2(60 + (60 * UI_Inventory_Crafting_RecipeList_Content.childCount), 124);
        Crafting_Text_ItemToCraft.text = handler.objects.Blueprints[recipeID].Name;
        string str = "";
        for (var i = 0; i < handler.objects.Blueprints[recipeID].Material_Names.Length; i++)
        {
            str = str + handler.objects.Blueprints[recipeID].Material_Names[i].ToString() + "\n";
        }
        Crafting_Text_Materials.text = str;
    }
    public void Crafting_ChangeID(int amount)
    {
        recipeID += amount;
        Mathf.Clamp(recipeID, 0, handler.objects.Blueprints.Length);
    }
    public void Crafting_CraftItem()
    {
        Entity_Player player = handler.world.Player.GetComponent<Entity_Player>();
        Object_Blueprint recipe = handler.objects.Blueprints[recipeID];

        int craftPercent = 0;
        List<int> itemsInRecipe = new List<int>(recipe.Materials.Length);
        for (int i = 0; i < itemsInRecipe.Count; i++)
        {
            itemsInRecipe[i] = -1;
        }

        foreach (ScriptableObject material in recipe.Materials)
        {
            for (int i = 0; i < player.MyInventory.Inventory.Length; i++)
            {
                int ID = handler.objects.getItemID(material);
                if (ID == player.MyInventory.Inventory[i] && !itemsInRecipe.Contains(i))
                {
                    itemsInRecipe.Add(i);
                    craftPercent++;
                    break;
                }
            }
        }
        if (craftPercent == recipe.Materials.Length)
        {
            foreach (int a in itemsInRecipe)
            {
                player.MyInventory.Inventory_DeleteItem(a);
            }
            player.MyInventory.Inventory_NewItem(handler.objects.getItemID(recipe.ToCraft));
        }
    }
}
