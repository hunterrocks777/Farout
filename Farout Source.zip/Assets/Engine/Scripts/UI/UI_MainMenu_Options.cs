﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;

public class UI_MainMenu_Options : MonoBehaviour
{
    public Dropdown Gameplay_Difficulty;
    public Dropdown Gameplay_MouseSpeed;
    public Dropdown Graphics_Quality;
    public Dropdown Graphics_Resolution;
    public Dropdown Graphics_ChunkDist;
    public Toggle Gameplay_ShowHUD;
    public Toggle Graphics_Fullscreen;
    public Toggle Graphics_PostProcessing;
    public Dropdown Audio_Effects;
    public Dropdown Audio_Music;
    private void Start()
    {
        SetValues();
    }
    public void SetValues() 
    {
        Game_PlayerPreferences PrefsLoading = new Game_PlayerPreferences();
        Handler_PlayerPrefs prefs = FindObjectOfType<Handler_PlayerPrefs>();
        string jsonSavePath = Application.persistentDataPath + "/" + prefs.PreferencesFileName;
        if (File.Exists(jsonSavePath))
        {
            PrefsLoading = JsonUtility.FromJson<Game_PlayerPreferences>(File.ReadAllText(jsonSavePath));
        }
        Gameplay_ShowHUD.isOn = PrefsLoading.Gameplay_ShowHUD;
        //Difficulty
        if (PrefsLoading.Gameplay_Difficulty == 0.25f)
        {
            Gameplay_Difficulty.value = 0;
        }
        if (PrefsLoading.Gameplay_Difficulty == 0.5f)
        {
            Gameplay_Difficulty.value = 1;
        }
        if (PrefsLoading.Gameplay_Difficulty == 1f)
        {
            Gameplay_Difficulty.value = 2;
        }
        if (PrefsLoading.Gameplay_Difficulty == 1.25f)
        {
            Gameplay_Difficulty.value = 3;
        }
        if (PrefsLoading.Gameplay_Difficulty == 1.5f)
        {
            Gameplay_Difficulty.value = 4;
        }
        //Mouse Speed
        if (PrefsLoading.Gameplay_MouseSpeed == 2)
        {
            Gameplay_MouseSpeed.value = 0;
        }
        if (PrefsLoading.Gameplay_MouseSpeed == 4)
        {
            Gameplay_MouseSpeed.value = 1;
        }
        if (PrefsLoading.Gameplay_MouseSpeed == 6)
        {
            Gameplay_MouseSpeed.value = 2;
        }
        if (PrefsLoading.Gameplay_MouseSpeed == 8)
        {
            Gameplay_MouseSpeed.value = 3;
        }
        if (PrefsLoading.Gameplay_MouseSpeed == 10)
        {
            Gameplay_MouseSpeed.value = 4;
        }
        //Graphics
        Graphics_Quality.value = PrefsLoading.Graphics_Quality;
        Graphics_ChunkDist.value = PrefsLoading.Graphics_ChunkDist - 1;
        //Resolution
        if (PrefsLoading.Graphics_ResolutionX == 1280)
        {
            Graphics_Resolution.value = 0;
        }
        if (PrefsLoading.Graphics_ResolutionX == 1920)
        {
            Graphics_Resolution.value = 1;
        }
        Graphics_Fullscreen.isOn = PrefsLoading.Graphics_Fullscreen;
        Graphics_PostProcessing.isOn = PrefsLoading.Graphics_PostProcessing;
        //Audio
        if (PrefsLoading.Audio_Effects == 0)
        {
            Audio_Effects.value = 0;
        }
        if (PrefsLoading.Audio_Effects == 25)
        {
            Audio_Effects.value = 1;
        }
        if (PrefsLoading.Audio_Effects == 50)
        {
            Audio_Effects.value = 2;
        }
        if (PrefsLoading.Audio_Effects == 75)
        {
            Audio_Effects.value = 3;
        }
        if (PrefsLoading.Audio_Effects == 100)
        {
            Audio_Effects.value = 4;
        }
        //Music
        if (PrefsLoading.Audio_Music == 0)
        {
            Audio_Music.value = 0;
        }
        if (PrefsLoading.Audio_Music == 25)
        {
            Audio_Music.value = 1;
        }
        if (PrefsLoading.Audio_Music == 50)
        {
            Audio_Music.value = 2;
        }
        if (PrefsLoading.Audio_Music == 75)
        {
            Audio_Music.value = 3;
        }
        if (PrefsLoading.Audio_Music == 100)
        {
            Audio_Music.value = 4;
        }
    }
    public void SaveApplyPrefs()
    {
        Handler_PlayerPrefs prefs = FindObjectOfType<Handler_PlayerPrefs>();
        prefs.Prefs.Gameplay_ShowHUD = Gameplay_ShowHUD.isOn;
        //Difficulty
        if (Gameplay_Difficulty.value == 0)
        {
            prefs.Prefs.Gameplay_Difficulty = 0.25f;
        }
        if (Gameplay_Difficulty.value == 1)
        {
            prefs.Prefs.Gameplay_Difficulty = 0.5f;
        }
        if (Gameplay_Difficulty.value == 2)
        {
            prefs.Prefs.Gameplay_Difficulty = 1f;
        }
        if (Gameplay_Difficulty.value == 3)
        {
            prefs.Prefs.Gameplay_Difficulty = 1.25f;
        }
        if (Gameplay_Difficulty.value == 4)
        {
            prefs.Prefs.Gameplay_Difficulty = 1.5f;
        }
        //Mouse Speed
        if (Gameplay_MouseSpeed.value == 0)
        {
            prefs.Prefs.Gameplay_MouseSpeed = 2;
        }
        if (Gameplay_MouseSpeed.value == 1)
        {
            prefs.Prefs.Gameplay_MouseSpeed = 4;
        }
        if (Gameplay_MouseSpeed.value == 2)
        {
            prefs.Prefs.Gameplay_MouseSpeed = 6;
        }
        if (Gameplay_MouseSpeed.value == 3)
        {
            prefs.Prefs.Gameplay_MouseSpeed = 8;
        }
        if (Gameplay_MouseSpeed.value == 4)
        {
            prefs.Prefs.Gameplay_MouseSpeed = 10;
        }
        //Graphics
        prefs.Prefs.Graphics_Quality = Graphics_Quality.value;
        prefs.Prefs.Graphics_ChunkDist = Graphics_ChunkDist.value + 1;
        //Resolution
        if (Graphics_Resolution.value == 0)
        {
            prefs.Prefs.Graphics_ResolutionX = 1280;
            prefs.Prefs.Graphics_ResolutionY = 720;
        }
        if (Graphics_Resolution.value == 1)
        {
            prefs.Prefs.Graphics_ResolutionX = 1920;
            prefs.Prefs.Graphics_ResolutionY = 1080;
        }
        prefs.Prefs.Graphics_Fullscreen = Graphics_Fullscreen.isOn;
        prefs.Prefs.Graphics_PostProcessing = Graphics_PostProcessing.isOn;
        //Audio
        if (Audio_Effects.value == 0)
        {
            prefs.Prefs.Audio_Effects = 0;
        }
        if (Audio_Effects.value == 1)
        {
            prefs.Prefs.Audio_Effects = 25;
        }
        if (Audio_Effects.value == 2)
        {
            prefs.Prefs.Audio_Effects = 50;
        }
        if (Audio_Effects.value == 3)
        {
            prefs.Prefs.Audio_Effects = 75;
        }
        if (Audio_Effects.value == 4)
        {
            prefs.Prefs.Audio_Effects = 100;
        }
        //Music
        if (Audio_Music.value == 0)
        {
            prefs.Prefs.Audio_Music = 0;
        }
        if (Audio_Music.value == 1)
        {
            prefs.Prefs.Audio_Music = 25;
        }
        if (Audio_Music.value == 2)
        {
            prefs.Prefs.Audio_Music = 50;
        }
        if (Audio_Music.value == 3)
        {
            prefs.Prefs.Audio_Music = 75;
        }
        if (Audio_Music.value == 4)
        {
            prefs.Prefs.Audio_Music = 100;
        }

        prefs.SavePrefs();
    }
}
