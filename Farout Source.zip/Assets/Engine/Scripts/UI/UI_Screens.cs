﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UI_Screens : MonoBehaviour
{
    public string UI_CurrentCanvas;
    public Canvas[] UI_Canvases;
    public bool MainUI;

    Handler_Gamehandler handler;

    void Start()
    {
        handler = FindObjectOfType<Handler_Gamehandler>();
    }
    public void UI_ChangeScreen(string newScreen)
    {
        UI_CurrentCanvas = newScreen;
    }
    // Update is called once per frame
    void Update()
    {
        if (MainUI)
        {
            UI_CurrentCanvas = handler.World_UIScreen;
        }
        foreach (Canvas can in UI_Canvases)
        {
            if (can.name == UI_CurrentCanvas)
            {
                if (can.name == "hud")
                {
                    if (handler.prefs.Prefs.Gameplay_ShowHUD)
                    {
                        can.enabled = true;
                    }
                    else 
                    {
                        can.enabled = false;
                    }
                }
                else 
                {
                    can.enabled = true;
                }
            }
            else
            {
                can.enabled = false;
            }
        }
    }
}
