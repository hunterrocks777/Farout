﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UI_WorldGeneration : MonoBehaviour
{
    public Dropdown UI_Dropdown_Environment;
    public InputField UI_InputField_Seed;

    public void Button_CreateWorld()
    {
        FindObjectOfType<Handler_Gamehandler>().World_UIScreen = "loading";
        int seed = 57357546;
        int environment = UI_Dropdown_Environment.value;

        if (UI_InputField_Seed.text != "")
        {
            seed = int.Parse(UI_InputField_Seed.text);
        }
        else 
        {
            seed = Random.Range(1000000, 9999999);
        }
        FindObjectOfType<Handler_MapHandler>().NewWorld(environment, seed);
    }
}
