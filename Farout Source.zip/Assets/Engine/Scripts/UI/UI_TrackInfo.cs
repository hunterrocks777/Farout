﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UI_TrackInfo : MonoBehaviour
{
    public bool Track_Day;
    public bool Track_Environment;
    public bool Track_Seed;
    public bool Track_Time;

    Handler_Gamehandler handler;
    Text ui_text;
    void Start()
    {
        handler = FindObjectOfType<Handler_Gamehandler>();
        ui_text = GetComponent<Text>();
    }
    void Update()
    {
        if (Track_Day) 
        {
            ui_text.text = "Days Survived: " + handler.world.Sun.Time_Day;
        }
        if (Track_Time) 
        {
            int time = (int) handler.world.Sun.Time_Time;
            if (time >= 12)
            {
                if (time == 12)
                {
                    ui_text.text = "12 PM";
                }
                else 
                {
                    ui_text.text = (time - 12).ToString() + " PM";
                }
            }
            else 
            {
                if (time == 0)
                {
                    ui_text.text = "12 AM";
                }
                else 
                {
                    ui_text.text = time + " AM";
                }
            }
        }
        if (Track_Environment)
        {
            ui_text.text = "Environment: " + handler.objects.Environments[handler.world.World_CurrentEnvironment].Name;
        }
        if (Track_Seed)
        {
            ui_text.text = "Seed: " + handler.world.World_Seed;
        }
    }
}
