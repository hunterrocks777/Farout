﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UI_TrackPlayer : MonoBehaviour
{
    public bool UI_Health;
    public bool UI_Death; //Appear on Death
    public bool UI_Health_RecentDamage;
    public bool UI_Stamina;
    public bool UI_ItemInSight;
    public bool UI_Hunger;
    public bool UI_Temperature;

    public Image UI_Counter;
    public Text UI_Text;

    Entity_Player player;
    private void Start()
    {
        UI_Text = GetComponent<Text>();
        player = FindObjectOfType<Entity_Player>();
    }

    private void Update()
    {
        if (UI_Health)
        {
            UI_Counter.fillAmount = (float)player.Player_Health / player.Player_Health_Max;
            if (player.Player_Health >= 25)
            {
                UI_Counter.color = Color.white;
            }
            else 
            {
                UI_Counter.color = Color.red;
            }
        }
        if (UI_Stamina)
        {
            UI_Counter.fillAmount = (float)player.Player_Stamina / player.Player_Stamina_Max;
            if (player.Player_Stamina_CanUse)
            {
                UI_Counter.color = Color.white;
            }
            else
            {
                UI_Counter.color = Color.red;
            }
        }
        if (UI_Death)
        {
            if (player.Player_Health <= 0) 
            {
                if (UI_Text) 
                {
                    UI_Text.enabled = true;
                }
                if (UI_Counter)
                {
                    UI_Counter.enabled = true;
                }
            }
            else 
            {
                if (UI_Text)
                {
                    UI_Text.enabled = false;
                }
                if (UI_Counter)
                {
                    UI_Counter.enabled = false;
                }
            }
        }
        if (UI_Hunger)
        {
            UI_Counter.fillAmount = (float)player.Player_Hunger / 100;
            if (player.Player_Hunger >= 25)
            {
                UI_Counter.color = Color.white;
            }
            else
            {
                UI_Counter.color = Color.red;
            }
        }
        if (UI_Temperature)
        {
            UI_Counter.fillAmount = Mathf.Lerp(UI_Counter.fillAmount, (float)player.Player_ActualTempurature / 100, 0.1f);
            if (UI_Counter.fillAmount >= 0.63f)
            {
                if (UI_Counter.fillAmount >= 0.8f)
                {
                    UI_Counter.color = Color.red;
                }
                else
                {
                    UI_Counter.color = Color.yellow;
                }
            }
            else
            {
                if (UI_Counter.fillAmount <= 0.37f)
                {
                    if (UI_Counter.fillAmount <= 0.2f)
                    {
                        UI_Counter.color = Color.blue;
                    }
                    else
                    {
                        UI_Counter.color = Color.cyan;
                    }
                }
                else
                {
                    UI_Counter.color = Color.white;
                }
            }
        }
        if (UI_ItemInSight) 
        {
            UI_Text.text = player.LookAt_Name;
        }
        if (UI_Health_RecentDamage)
        {
            if (player.Player_Health_RecentDamage > 0)
            {
                UI_Counter.enabled = true;
                UI_Counter.color = new Color(255, 255, 255, (player.Player_Health_RecentDamage * 5) / 100);
            }
            else
            {
                UI_Counter.enabled = false;
            }
        }
    }
}
