﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;

public class UI_Inventory : MonoBehaviour
{
    [HideInInspector] public Entity_Inventory Inventory;
    public int Inventory_CurrentID;

    public Text UI_Text_CurrentItemName;
    public Image UI_Image_CurrentItemSprite;

    public Text UI_Text_Use;
    public Text UI_Text_Drop;

    //References
    Entity_Player player;
    Handler_Gamehandler handler;
    private void Start()
    {
        handler = FindObjectOfType<Handler_Gamehandler>();
        player = FindObjectOfType<Entity_Player>();
        Inventory_Reset();
    }
    private void Update()
    {
        ScriptableObject b = handler.objects.Items[Inventory.Inventory[Inventory_CurrentID]];
        if (b is Object_Item)
        {
            UI_Text_CurrentItemName.text = ((Object_Item)b).Name;
            UI_Image_CurrentItemSprite.sprite = ((Object_Item)b).UI_Sprite;
        }
        if (b is Object_Weapon)
        {
            UI_Text_CurrentItemName.text = ((Object_Weapon)b).Name;
            UI_Image_CurrentItemSprite.sprite = ((Object_Weapon)b).UI_Sprite;
        }
        if (b is Object_Consumable)
        {
            UI_Text_CurrentItemName.text = ((Object_Consumable)b).Name;
            UI_Image_CurrentItemSprite.sprite = ((Object_Consumable)b).UI_Sprite;
        }
        if (b is Object_Buildable)
        {
            UI_Text_CurrentItemName.text = ((Object_Buildable)b).Name;
            UI_Image_CurrentItemSprite.sprite = ((Object_Buildable)b).UI_Sprite;
        }
    }
    //Basic
    public void Inventory_Reset()
    {
        Inventory = player.MyInventory;
        UI_Text_Use.text = "Equip";
        UI_Text_Drop.text = "Drop";
    }
    public void Inventory_OpenInventory(Entity_Inventory inven)
    {
        Inventory_OpenInventory(inven);
        if (inven == player.MyInventory)
        {
            UI_Text_Use.text = "Equip";
            UI_Text_Drop.text = "Drop";
        }
        else
        {
            UI_Text_Use.text = "Take";
            UI_Text_Drop.text = "Store";
        }
    }
    public void Inventory_SetID(int ID) 
    {
        Inventory_CurrentID = ID;
    }
    //Buttons
    public void Inventory_UseItem() 
    {
        Inventory.Inventory_UseItem(Inventory_CurrentID);
    }
    public void Inventory_DropItem()
    {
        Inventory.Inventory_DropItem(Inventory_CurrentID);
    }
    public void Inventory_SortItem()
    {
        Inventory.Inventory_Sort();
    }
    //Other Inventories (Chests)
    public void Inventory_TakeItem() 
    {
        int newItem = Inventory.Inventory[Inventory_CurrentID];
        player.MyInventory.Inventory_NewItem(newItem);
        Inventory.Inventory_DeleteItem(Inventory_CurrentID);
    }
}
