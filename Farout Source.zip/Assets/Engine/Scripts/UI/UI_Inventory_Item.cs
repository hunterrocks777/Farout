﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UI_Inventory_Item : MonoBehaviour
{
    public int UI_ID;
    public Image UI_Sprite;

    UI_Inventory inventory;
    Handler_Gamehandler handler;
    private void Start()
    {
        UI_ID = transform.GetSiblingIndex();
        handler = FindObjectOfType<Handler_Gamehandler>();
        inventory = FindObjectOfType<UI_Inventory>();
    }

    public void onButtonPress() 
    {
        inventory.Inventory_SetID(UI_ID);
    }

    private void Update()
    {
        ScriptableObject item = handler.objects.Items[inventory.Inventory.Inventory[UI_ID]];
        if (item is Object_Weapon) 
        {
            UI_Sprite.sprite = ((Object_Weapon)item).UI_Sprite;
        }
        if (item is Object_Item)
        {
            UI_Sprite.sprite = ((Object_Item)item).UI_Sprite;
        }
        if (item is Object_Consumable)
        {
            UI_Sprite.sprite = ((Object_Consumable)item).UI_Sprite;
        }
        if (item is Object_Buildable)
        {
            UI_Sprite.sprite = ((Object_Buildable)item).UI_Sprite;
        }
    }
}
